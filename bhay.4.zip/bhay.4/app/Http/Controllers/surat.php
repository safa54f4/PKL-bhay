<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Session;

class Surat extends Controller
{
    public function search(Request $request)
    {
        $code = $request->input('code');
        if ($code == "searchDokter") {
            $keyword = $request->input('search');
            $surat = DB::table('surat_visum')
                ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
                ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
                ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
                ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
                ->where('dokter.nm_dokter', 'like', "%{$keyword}%")
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10);

            $surat->appends($request->only(['_token', 'search', 'code']));
            // Return the search view with the resluts compacted
            return view('pages.surat', compact('surat'));
        } else if ($code == "searchPasien") {
            $keyword = $request->input('search');
            $surat = DB::table('surat_visum')
                ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
                ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
                ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
                ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
                ->where('pasien.nm_pasien', 'like', "%{$keyword}%")
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10)
                ;

            $surat->appends($request->only(['_token', 'search', 'code']));
            // Return the search view with the resluts compacted
            return view('pages.surat', compact('surat'));
        } else if ($code == "dateFilter") {
            $from = $request->input('from_date');
            $to = $request->input('to_date');
            $surat = DB::table('surat_visum')
                ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
                ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
                ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
                ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
                ->whereBetween('surat_visum.tanggalsurat', [$from, $to])
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10)
                ;

            $surat->appends($request->only(['_token', 'from_date', 'to_date', 'code']));
            // Return the search view with the resluts compacted
            return view('pages.surat', compact('surat'));
        } else if($code == "searchDokterPasien"){
            $keyword = $request->input('search');
            $surat = DB::table('surat_visum')
                ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
                ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
                ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
                ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
                ->where('pasien.nm_pasien', 'like', "%{$keyword}%")
                ->where('dokter.nm_dokter', 'like', "%{$keyword}%")
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10);

            $surat->appends($request->only(['_token', 'search', 'code']));
            // Return the search view with the resluts compacted
            return view('pages.surat', compact('surat'));
        }
    }

    public function index($param = null)
    {
        $str = str_replace('_', ' ', $param);
        if ($param == null || $param == 'Semua') {
            $date = date('Y-m-d');
            $surat = DB::table('surat_visum')
                ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
                ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
                ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
                ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
                ->where('surat_visum.tanggalsurat', $date)
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10)
                ;

        } else {
            $surat = DB::table('surat_visum')
                ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
                ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
                ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
                ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
                ->where('surat_visum.status', '=', $str)
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10)
                ;

        }

        return view('pages.surat', compact('surat'));

    }

    public function dashboard(){
        $suratAll = DB::table('surat_visum')
            ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
            ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
            ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
            ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
            ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
            ->get();

        $countSuratAll = count($suratAll);

        $suratSelesai = DB::table('surat_visum')
            ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
            ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
            ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
            ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
            ->where('surat_visum.status', '=', 'Selesai')
            ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
            ->get();

        $countSuratSelesai = count($suratSelesai);


        $suratDalamProses = DB::table('surat_visum')
            ->join('surat_instansi', 'surat_instansi.kd', '=', 'surat_visum.kd_instansi')
            ->leftjoin('reg_periksa', 'reg_periksa.no_rawat', '=', 'surat_visum.no_rawat')
            ->leftjoin('dokter', 'dokter.kd_dokter', '=', 'surat_visum.kd_dokter')
            ->leftjoin('pasien', 'reg_periksa.no_rkm_medis', '=', 'pasien.no_rkm_medis')
            ->where('surat_visum.status', '=', 'Dalam Proses')
            ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
            ->get();

        $countDalamProses = count($suratDalamProses);


        $surat = DB::table('surat_visum')
                ->select(\DB::raw("COUNT(*) as count"))
                ->whereYear('tanggalsurat', date('Y'))
                ->groupBy(\DB::raw("Month(tanggalsurat)"))
                ->pluck('count');

        $dokterTerbanyak = DB::table('dokter')
            ->join(\DB::raw("(SELECT kd_dokter, count(*) AS Number from surat_visum GROUP BY kd_dokter ORDER BY Number DESC) as o"), 'dokter.kd_dokter', "=", "o.kd_dokter")
            ->select("nm_dokter as name", "o.Number as y")
            ->get();
        $dataDoktor = array();
        foreach ($dokterTerbanyak as $doktor){
            $data = [$doktor->name, $doktor->y];
            array_push($dataDoktor, $data);
        }
        return view('pages.dashboard', compact(['dataDoktor', 'surat', 'countSuratAll', 'countSuratSelesai', 'countDalamProses']));
    }

}

