<?php

use App\Http\Controllers\Surat;
use App\Http\Controllers\Login;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::get('/login', [Login::class, 'index'])->name('login.index');
Route::post('/login', [Login::class, 'auth'])->name('login.auth');
Route::group(['middleware' => 'login'], function() {
    Route::get('/', [\App\Http\Controllers\Surat::class, 'dashboard'])->name('dashboard');
    Route::get('/surat', [\App\Http\Controllers\Surat::class, 'index'])->name('index');

    Route::get('/surat/{param}', [App\Http\Controllers\Surat::class,'index'])->name('surat');
    Route::get('/search', [Surat::class, 'search'])->name('search');

    Route::get('/logout', [Login::class, 'logout'])->name('logout');
});
