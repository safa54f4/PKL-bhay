<!doctype html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Data Visum</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/normalize.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('styleassets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/cs-skin-elastic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style/assets/scss/style.css')); ?>">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="breadcrumbs">
    <div class="col-sm-12">
        <div class="page-header text-center">
            <div class="page-title">
                <div class="row">
                    <div class="col-lg-6">
                        <!-- <center><h1 align="center">Data Visum</h1></center> -->
                    </div>
                   
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                
                  <center><h2 align="center">LAPORAN PEMERIKSAAN VISUM RUMKIT BHAYANGKARA TK. III NGANJUK</h2></center>
            </div>
            <div align="right">
                        <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Logout</a></div>

                        
            <div class="breadcrumbs">
                <!-- <h3 align="center">Live search in laravel using AJAX</h3><br /> -->
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Search</div> -->
                    <div class="panel-body">
                        <div class="card-body">
                        <div class="row pb-4">
                                <div class="col-sm-3">
                                    <form action="<?php echo e(route('search')); ?>" method="GET">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="code" value="searchDokter"/>
                                        <!-- <label>Cari berdasarkan nama dokter</label> -->
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" name="search" placeholder="Cari Nama dokter"
                                                   aria-label="Nama dokter" aria-describedby="basic-addon2">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="submit">Cari</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-sm-3">
                                    <form action="<?php echo e(route('search')); ?>" method="GET">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="code" value="searchPasien"/>
                                        <!-- <label>Cari berdasarkan nama pasien</label> -->
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" name="search" placeholder="Cari Nama pasien" aria-label="Nama pasien" aria-describedby="basic-addon2">
                                            <div class="input-group-append">
                                                <button class="btn btn-primary" type="submit">Cari</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                           
                                 <div class="row pb-4">
                                    <div class="col-6 col-md-1">
                                        <!-- <label>Filter status</label> -->
                                        <select id="filter" name="filter" class="form-control filter" onchange="filter()">
                                            <option value="Semua" selected>Filter Status</option>
                                            <option value="Semua">All</option>
                                            <option value="Selesai">Selesai</option>
                                            <option value="Dalam_Proses">Dalam Proses</option>
                                        </select>
                                    </div>
                                </div>
                            <br/>
                            <form action="<?php echo e(route('search')); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="code" value="dateFilter"/>
                                <div class="row">
                                    <div class="col-6 col-md-2">
                                        <!-- <label>Dari Tanggal</label> -->
                                        <input type="date" name="from_date" id="from_date" class="form-control"
                                               placeholder="Dari tanggal"/>
                                    </div>
                                    <label class="mt-auto">SD</label>
                                    <div class="col-md-2">
                                        <!-- <label>Sampai Tanggal</label> -->
                                        <input type="date" name="to_date" id="to_date" class="form-control"
                                               placeholder="Sampai tanggal"/>
                                    </div>
                                    <div class="col-md-2 mt-auto">
                                        <button type="submit" name="filter" id="filter" class="btn btn-primary">Filter</button>
                                        <button type="button" name="refresh" id="refresh" class="btn btn-default">
                                            Reset
                                        </button>
                                    </div>
                                </div>
                            </form>
                         
                        </div>
                        
                        <br/>
                        
                        <div class="card-body">
                            <table class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <td>No</td>
                                    <td>No surat</td>
                                    <td>tanggal</td>
                                    <td>nama dokter</td>
                                    <td>No rawat</td>
                                    <td>Nama</td>
                                    <td>Kategori</td>
                                    <td>Instansi</td>
                                    <td>Status</td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($surat) > 0): ?>
                                <?php $i = 0 ?>
                                    <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++ ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($item->no_surat); ?></td>
                                            <td><?php echo e($item->tanggalsurat); ?></td>
                                            <td><?php echo e($item->nm_dokter); ?></td>
                                            <td><?php echo e($item->no_rawat); ?></td>
                                            <td><?php echo e($item->nm_pasien); ?></td>
                                            <td><?php echo e($item->kategori); ?></td>
                                            <td><?php echo e($item->instansi); ?></td>
                                            <td><?php echo e($item->status); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8">Data tidak ada</td>
                                    </tr>
                                <?php endif; ?>


                                </tbody>
                            </table>
                            Halaman : <?php echo e($surat->currentPage()); ?> <br/>
                            Jumlah Data : <?php echo e($surat->total()); ?> <br/>
                            Data Per Halaman : <?php echo e($surat->perPage()); ?> <br/>
                            <?php echo e($surat->links('vendor.pagination.bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .animated -->
    </div><!-- .content -->
</div><!-- /#right-panel -->

<script src="<?php echo e(asset('style/assets/js/vendor/jquery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/main.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('style/assets/js/lib/data-table/datatables-init.js')); ?>"></script>

<script>
    function filter(){
        var x = document.getElementById("filter").value;
        window.location.replace('http://localhost:8000/surat/'+ x);
    }
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\bhay.2\resources\views/main.blade.php ENDPATH**/ ?>