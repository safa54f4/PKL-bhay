<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title">Surat</h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->

        <!-- Card -->
        <div class="card mb-3 mb-lg-5">
            <!-- Header -->
            <div class="card-header">
                <div class="row justify-content-between align-items-center flex-grow-1">
                    <div class="col-12 col-md">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-header-title">LAPORAN PEMERIKSAAN VISUM RUMKIT BHAYANGKARA TK. III NGANJUK</h5>
                        <br/>

                        </div>
                        <br/>
                    </div>
                </div>

            </div>
            <!-- End Header -->

            <!-- Table -->
            <div class="table-responsive">
                <div class="container">

                    <div class="row pb-4">
                        <div class="col-sm-6">
                            <form action="<?php echo e(route('search')); ?>" method="GET">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="code" value="searchDokterPasien"/>
                                <!-- <label>Cari berdasarkan nama dokter</label> -->
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" name="search"
                                           placeholder="Cari Nama dokter / pasien"
                                           aria-label="Nama dokter / pasien" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">Cari</button>
                                    </div>
                                </div>
                            </form>
                        </div>















                    </div>


                    <form action="<?php echo e(route('search')); ?>" method="GET">
                        <?php echo csrf_field(); ?>
                        <div class="row pb-4">
                            <div class="col-sm-12 col-md-6">
                                <!-- <label>Filter status</label> -->
                                <select id="filter" name="filterStatus" class="form-control filter">
                                    <option value="">Filter Status</option>
                                    <option value="Semua">All</option>
                                    <option value="Selesai">Selesai</option>
                                    <option value="Dalam Proses">Dalam Proses</option>
                                </select>
                            </div>
                        </div>
                        <input type="hidden" name="code" value="dateFilter"/>
                        <div class="row">
                            <div class="col-sm-12 col-md-2">
                                <input type="date" name="from_date" id="from_date" class="form-control"
                                value="<?php echo date('Y-m-d'); ?>"/>
                            </div>
                            <div class="col-sm-11 col-md-1 text-center">
                                <label class="mt-auto">SD</label>
                            </div>
                            <div class="col-sm-11 col-md-2">
                                <input type="date" name="to_date" id="to_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" />
                            </div>
                            <div class="col-sm-12 col-md-3 mt-auto">
                                <div class="row">
                                    <div class="col-sm-12 col-md-4">
                                        <button type="submit" id="filter" class="btn btn-primary btn-block">Filter
                                        </button>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <!-- <button type="button" name="refresh" id="refresh" class="btn btn-default btn-block">
                                            Reset
                                        </button> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <br/>

                <table class="table table-bordered table-thead-bordered table-nowrap table-align-middle card-table">
                    <thead>
                    <tr>
                        <td>No</td>
                        <td>No surat</td>
                        <td>tanggal</td>
                        <td>nama dokter</td>
                        <td>No rawat</td>
                        <td>Nama</td>
                        <td>Kategori</td>
                        <td>Instansi</td>
                        <td>Status</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($surat) > 0): ?>
                        <?php $i = 0 ?>
                        <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php $i++ ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($item->no_surat); ?></td>
                                <td><?php echo e($item->tanggalsurat); ?></td>
                                <td><?php echo e($item->nm_dokter); ?></td>
                                <td><?php echo e($item->no_rawat); ?></td>
                                <td><?php echo e($item->nm_pasien); ?></td>
                                <td><?php echo e($item->kategori); ?></td>
                                <td><?php echo e($item->instansi); ?></td>
                                <td><?php echo e($item->status); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8">Data tidak ada</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <br/>
            <!-- End Table -->
                Halaman : <?php echo e($surat->currentPage()); ?> <br/>
                    Jumlah Data : <?php echo e($surat->total()); ?> <br/>
                    Data Per Halaman : <?php echo e($surat->perPage()); ?> <br/>
                    <br/>

                    <!-- Pagination -->

            </div>
            <br/>
            <?php echo e($surat->onEachSide(3)->links('vendor.pagination.bootstrap-4')); ?>


            <!-- Footer -->
            <div class="card-footer">
                <!-- Pagination -->
                <div class="row justify-content-center justify-content-sm-between align-items-sm-center">
                    <div class="col-sm-auto">
                        <div class="d-flex justify-content-center justify-content-sm-end">

                        </div>
                    </div>
                </div>
                <!-- End Pagination -->
            </div>
            <!-- End Footer -->
        </div>
        <!-- End Card -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('jsCode'); ?>









<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PKL-bhay-main\PKL-bhay-main\bhay\resources\views/pages/surat.blade.php ENDPATH**/ ?>