<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;

class Login extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function auth(Request $request)
    {
        if($request->email == "info@rsbhayangkaranganjuk.com" && $request->password == "polripresisi"){
            Session::put('login', 'yes');
            return redirect()->route('index')
                ->with('success', 'Berhasil Login');
        }else{
            return redirect()->route('login.index')
                ->with('failed', 'Gagal Login');
        }
    }

    public function logout(){
        Session::forget('login');
        return redirect()->route('login.index')
            ->with('success', 'Berhasil Logout');
    }
}
