<?php

namespace App\Http\Controllers;
use DB;

use Illuminate\Http\Request;

class Surat extends Controller
{
     public function search(Request $request)
     {
         $code = $request->input('code');
         if($code == "searchDokter"){
             $keyword = $request->input('search');
             $surat = DB::table('surat_visum')
                 ->join('surat_instansi','surat_instansi.kd','=','surat_visum.kd_instansi')
                 ->leftjoin('reg_periksa','reg_periksa.no_rawat','=','surat_visum.no_rawat')
                 ->leftjoin('dokter','dokter.kd_dokter','=','surat_visum.kd_dokter')
                 ->leftjoin('pasien','reg_periksa.no_rkm_medis','=','pasien.no_rkm_medis')
                 ->where('dokter.nm_dokter', 'like', "%{$keyword}%")
                 ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                 ->paginate(10);

             $surat->appends($request->only(['_token', 'search', 'code']));
             // Return the search view with the resluts compacted
             return view('main', compact('surat'));
         }else if($code == "searchPasien"){
             $keyword = $request->input('search');
             $surat = DB::table('surat_visum')
                 ->join('surat_instansi','surat_instansi.kd','=','surat_visum.kd_instansi')
                 ->leftjoin('reg_periksa','reg_periksa.no_rawat','=','surat_visum.no_rawat')
                 ->leftjoin('dokter','dokter.kd_dokter','=','surat_visum.kd_dokter')
                 ->leftjoin('pasien','reg_periksa.no_rkm_medis','=','pasien.no_rkm_medis')
                 ->where('pasien.nm_pasien', 'like', "%{$keyword}%")
                 ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                 ->paginate(10);

             $surat->appends($request->only(['_token', 'search', 'code']));
             // Return the search view with the resluts compacted
             return view('main', compact('surat'));
         }else if($code == "dateFilter"){
             $from = $request->input('from_date');
             $to = $request->input('to_date');
             $surat = DB::table('surat_visum')
                 ->join('surat_instansi','surat_instansi.kd','=','surat_visum.kd_instansi')
                 ->leftjoin('reg_periksa','reg_periksa.no_rawat','=','surat_visum.no_rawat')
                 ->leftjoin('dokter','dokter.kd_dokter','=','surat_visum.kd_dokter')
                 ->leftjoin('pasien','reg_periksa.no_rkm_medis','=','pasien.no_rkm_medis')
                 ->whereBetween('surat_visum.tanggalsurat', [$from, $to])
                 ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                 ->paginate(10);

             $surat->appends($request->only(['_token', 'from_date', 'to_date', 'code']));
             // Return the search view with the resluts compacted
             return view('main', compact('surat'));
         }
     }
//     public function search(Request $request)
//     {
//         $surat = Surat::where([
//             ['name', '!=', Null],
//             [function ($query) use ($request){
//                 if(($term = $request->term)) {
//                     $query->orWhere('name', 'Like', '%' . $term . '%')->get();
//                 }
//             }]
//         ])
//         ->orderBy("id", "desc")
//         ->paginate(10);
//
//         return view('surat.index' , compact('projects'))
//         ->with('i', (request()->input('page', 1) -1) *5);
//     }

    public function index($param = null)
    {
        $str = str_replace('_', ' ', $param);
        if($param == null || $param == 'Semua'){

            $surat = DB::table('surat_visum')
                ->join('surat_instansi','surat_instansi.kd','=','surat_visum.kd_instansi')
                ->leftjoin('reg_periksa','reg_periksa.no_rawat','=','surat_visum.no_rawat')
                ->leftjoin('dokter','dokter.kd_dokter','=','surat_visum.kd_dokter')
                ->leftjoin('pasien','reg_periksa.no_rkm_medis','=','pasien.no_rkm_medis')
                ->whereBetween('surat_visum.tanggalsurat', ['2020-01-01','2021-12-31'])
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10);

        }else{
            $surat = DB::table('surat_visum')
                ->join('surat_instansi','surat_instansi.kd','=','surat_visum.kd_instansi')
                ->leftjoin('reg_periksa','reg_periksa.no_rawat','=','surat_visum.no_rawat')
                ->leftjoin('dokter','dokter.kd_dokter','=','surat_visum.kd_dokter')
                ->leftjoin('pasien','reg_periksa.no_rkm_medis','=','pasien.no_rkm_medis')
                ->whereBetween('surat_visum.tanggalsurat', ['2020-01-01','2021-12-31'])
                ->where('surat_visum.status','=',$str)
                ->select('surat_visum.*', 'surat_instansi.instansi', 'reg_periksa.no_rkm_medis', 'dokter.nm_dokter', 'pasien.nm_pasien')
                ->paginate(10);

        }

        return view('main', compact('surat'));

    }
}
